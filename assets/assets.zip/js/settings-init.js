"use strict"
var optionSettings = {
    layout:"wide",
    background:"origin",
    color:"black",
    header:"fixed",
    font:"poppins",
    textDirection:"ltr",
    showSettings:"hide",
};
new antlerSettings(optionSettings);